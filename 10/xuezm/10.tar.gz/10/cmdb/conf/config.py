#coding=utf8

#database
db_host='139.198.9.83'
db_port='3306'
db_user='root'
db_password='xuezm'
db_name='cmdb'
db_charset='utf8'




